const path = require('path')
const {app, BrowserWindow, dialog } = require('electron')

var mainWindow = null

function initialize () {
    function createWindow () {
        const windowOptions = {
            width: 720,
            minWidth: 720,
            height: 720,
            title: app.getName(),
            autoHideMenuBar: true,
            webPreferences: {
                nodeIntegration: true,
                contextIsolation: false,
            }
        }
        mainWindow = new BrowserWindow(windowOptions)
        mainWindow.loadURL(path.join('file://', __dirname, '../../../index.html'))
        mainWindow.setFullScreen(true)
        //mainWindow.webContents.openDevTools()
    }

    app.on('ready', () => {
        createWindow()
    })

    app.on('window-all-closed', () => {
        if (process.platform !== 'darwin') {
            app.quit()
        }
    })

    app.on('activate', () => {
        if (mainWindow === null) {
            createWindow()
        }
    })
}

initialize();