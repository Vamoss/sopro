const path = require('path')
const {app, BrowserWindow, dialog } = require('electron')

var mainWindow = null

function initialize () {
    function createWindow () {
        const windowOptions = {
            width: 720,
            minWidth: 720,
            height: 720,
            title: app.getName(),
            autoHideMenuBar: true,
            webPreferences: {
                nodeIntegration: true,
                contextIsolation: false,
            }
        }
        //dialog.showMessageBox(mainWindow, {title:'s', message: app.getPath("exe") })
        mainWindow = new BrowserWindow(windowOptions)
        mainWindow.loadFile('/Users/carlos/Documents/Projects/sopro/index.html')
        mainWindow.setFullScreen(true)
        //mainWindow.webContents.openDevTools()
    }

    app.on('ready', () => {
        createWindow()
    })

    app.on('window-all-closed', () => {
        if (process.platform !== 'darwin') {
            app.quit()
        }
    })

    app.on('activate', () => {
        if (mainWindow === null) {
            createWindow()
        }
    })
}

initialize();